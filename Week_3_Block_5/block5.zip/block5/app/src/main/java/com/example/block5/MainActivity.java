package com.example.block5;

import android.graphics.Color;
import android.os.Bundle;

import android.support.v7.app.AppCompatActivity;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        final RelativeLayout layout = (RelativeLayout) findViewById(R.id.layout);

        RadioGroup radioGroup_colors = (RadioGroup) findViewById(R.id.radioGroup_colors);
        radioGroup_colors.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if (i == R.id.radioButton_blue)
                    layout.setBackgroundColor(Color.BLUE);
                else if (i == R.id.radioButton_magenta)
                    layout.setBackgroundColor(Color.MAGENTA);
                else if (i == R.id.radioButton_yellow)
                    layout.setBackgroundColor(Color.YELLOW);
            }

        });

    }
}

